# WhatsApp Automation Console

Private WhatsApp Web session dashboard and background automation worker. Link one account with a QR code or pairing code, monitor connection health, and manage message, presence, Status, command, reply, and group-welcome automation.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/whatsapp-automation-bot run dev` — run the dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `SESSION_SECRET` is available for future session protection. The WhatsApp worker stores its linked browser session in `.wwebjs_auth` unless `WHATSAPP_AUTH_DIR` is set.
- Optional env: `CHROME_BIN` overrides the Chromium executable used by Puppeteer.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/lib/whatsapp.ts` — WhatsApp Web worker, QR/pairing state, automation settings, metrics, and event log.
- `artifacts/api-server/src/routes/whatsapp.ts` — dashboard API routes under `/api/whatsapp`.
- `artifacts/whatsapp-automation-bot/src/pages/home.tsx` — live dashboard UI.
- `lib/api-spec/openapi.yaml` — source-of-truth API contract for generated client hooks and Zod schemas.

## Architecture decisions

- `whatsapp-web.js` uses `LocalAuth` so a successful QR link survives API restarts.
- The dashboard polls status and events instead of adding a WebSocket dependency.
- Automation is controlled by explicit settings and emits structured events for reads, reactions, delays, warnings, and errors.
- Presence refresh is best-effort; WhatsApp can change protocol behavior and account restrictions.

## Product

- QR linking or phone-number pairing-code linking with a persisted browser session.
- Connection health, account/device details, uptime, message-read count, and Status-reaction count.
- Toggleable auto-read, presence refresh, Status reactions, command replies, DM auto-reply, group welcomes, and ignored phone numbers.

## User preferences

The implementation follows the uploaded WhatsApp automation project and keeps the dashboard private by default.

## Gotchas

- Keep the live QR code private; add access control before publishing the dashboard.
- `whatsapp-web.js` is a third-party automation library and WhatsApp availability, presence semantics, and acknowledgements depend on its current protocol.
- The API server bridges the CommonJS WhatsApp package through `createRequire` and discovers Chromium from `CHROME_BIN` or `which chromium`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
