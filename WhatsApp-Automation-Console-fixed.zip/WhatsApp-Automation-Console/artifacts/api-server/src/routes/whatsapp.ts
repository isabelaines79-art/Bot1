import { Router, type IRouter } from "express";
import {
  ListWhatsappEventsQueryParams,
  PairWhatsappBody,
  UpdateWhatsappSettingsBody,
} from "@workspace/api-zod";
import { whatsappAutomation } from "../lib/whatsapp";

const router: IRouter = Router();

router.get("/whatsapp/status", (_req, res) => {
  res.json(whatsappAutomation.getSnapshot());
});

router.post("/whatsapp/start", (_req, res) => {
  void whatsappAutomation.start();
  res.json(whatsappAutomation.getSnapshot());
});

router.post("/whatsapp/pair", async (req, res) => {
  const parsed = PairWhatsappBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid phone number" });
    return;
  }

  try {
    await whatsappAutomation.requestPhonePairing(parsed.data.phoneNumber);
    res.json(whatsappAutomation.getSnapshot());
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Could not request a pairing code" });
  }
});

router.post("/whatsapp/use-qr", async (_req, res) => {
  await whatsappAutomation.useQrCode();
  res.json(whatsappAutomation.getSnapshot());
});

router.post("/whatsapp/logout", async (_req, res) => {
  await whatsappAutomation.logout();
  res.json(whatsappAutomation.getSnapshot());
});

router.patch("/whatsapp/settings", (req, res) => {
  const parsed = UpdateWhatsappSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid settings" });
    return;
  }

  try {
    whatsappAutomation.updateSettings(parsed.data as Parameters<typeof whatsappAutomation.updateSettings>[0]);
    res.json(whatsappAutomation.getSnapshot());
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Invalid settings" });
  }
});

router.get("/whatsapp/events", (req, res) => {
  const parsed = ListWhatsappEventsQueryParams.safeParse(req.query);
  const limit = parsed.success ? parsed.data.limit : 30;
  res.json(whatsappAutomation.getEvents(limit));
});

router.get("/whatsapp/chats", async (req, res) => {
  const rawLimit = Number(req.query.limit ?? 50);
  const limit = Number.isFinite(rawLimit) ? Math.min(100, Math.max(1, rawLimit)) : 50;
  try {
    res.json(await whatsappAutomation.getChats(limit));
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Could not load chats" });
  }
});

router.get("/whatsapp/chat-messages", async (req, res) => {
  const chatId = typeof req.query.chatId === "string" ? req.query.chatId : "";
  const rawLimit = Number(req.query.limit ?? 50);
  const limit = Number.isFinite(rawLimit) ? Math.min(100, Math.max(1, rawLimit)) : 50;
  if (!chatId) {
    res.status(400).json({ error: "A chat id is required" });
    return;
  }
  try {
    res.json(await whatsappAutomation.getChatMessages(chatId, limit));
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Could not load messages" });
  }
});

router.post("/whatsapp/chat-messages", async (req, res) => {
  const chatId = typeof req.body?.chatId === "string" ? req.body.chatId : "";
  const body = typeof req.body?.body === "string" ? req.body.body : "";
  try {
    res.json(await whatsappAutomation.sendChatMessage(chatId, body));
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Could not send message" });
  }
});

export default router;