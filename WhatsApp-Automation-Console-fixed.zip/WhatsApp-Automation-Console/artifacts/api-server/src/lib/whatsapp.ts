import { randomInt } from "node:crypto";
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import type { Client as WhatsappClient, Message } from "whatsapp-web.js";
import type * as QrCodeModule from "qrcode";

import { logger } from "./logger";

const require = createRequire(import.meta.url);
const { Client, LocalAuth } = require("whatsapp-web.js") as typeof import("whatsapp-web.js");
const QRCode = require("qrcode") as typeof QrCodeModule;

export type WhatsappState =
  | "idle"
  | "initializing"
  | "qr"
  | "pairing_code"
  | "authenticated"
  | "ready"
  | "disconnected"
  | "auth_failure"
  | "error";

export type WhatsappEventType =
  | "info"
  | "connected"
  | "qr"
  | "pairing_code"
  | "message_read"
  | "message_reacted"
  | "status_reacted"
  | "member_joined"
  | "command_replied"
  | "auto_replied"
  | "warning"
  | "error";

export interface WhatsappSettings {
  autoRead: boolean;
  autoReactMessages: boolean;
  autoReactStatus: boolean;
  keepPresenceOnline: boolean;
  randomDelayMin: number;
  randomDelayMax: number;
  // Extra automation functions
  commandsEnabled: boolean;
  autoReply: boolean;
  autoReplyMessage: string;
  welcomeNewMembers: boolean;
  welcomeMessage: string;
  ignoredNumbers: string[];
}

export interface WhatsappEvent {
  id: string;
  type: WhatsappEventType;
  message: string;
  detail: string | null;
  createdAt: string;
}

export interface WhatsappChat {
  id: string;
  name: string;
  isGroup: boolean;
  unreadCount: number;
  lastMessageAt: string | null;
  lastMessage: string | null;
}

export interface WhatsappChatMessage {
  id: string;
  body: string;
  fromMe: boolean;
  author: string | null;
  timestamp: number;
}

type WhatsappChatSummary = WhatsappChat & {
  timestamp: number | null;
};

export interface WhatsappSnapshot {
  state: WhatsappState;
  ready: boolean;
  qrDataUrl: string | null;
  pairingCode: string | null;
  pairingPhoneNumber: string | null;
  account: string | null;
  device: string | null;
  lastError: string | null;
  lastConnectedAt: string | null;
  settings: WhatsappSettings;
  events: WhatsappEvent[];
  metrics: {
    messagesRead: number;
    statusesReacted: number;
    uptimeSeconds: number;
  };
}

const DEFAULT_SETTINGS: WhatsappSettings = {
  autoRead: true,
  autoReactMessages: true,
  autoReactStatus: true,
  keepPresenceOnline: true,
  randomDelayMin: 1,
  randomDelayMax: 10,
  commandsEnabled: true,
  autoReply: false,
  autoReplyMessage: "Thanks for your message — I'll get back to you soon.",
  welcomeNewMembers: false,
  welcomeMessage: "Welcome to the group! 👋",
  ignoredNumbers: [],
};

const MAX_EVENTS = 100;
const AUTO_REPLY_COOLDOWN_MS = 60 * 60 * 1000; // don't auto-reply to the same chat more than once an hour

function asErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function normalizeDigits(value: string): string {
  return value.replace(/\D/g, "");
}

function normalizePairingPhoneNumber(value: string): string {
  const digits = normalizeDigits(value);
  // The dashboard is primarily used with Nigerian numbers. Accept the
  // familiar local 11-digit format as well as WhatsApp's international form.
  if (digits.length === 11 && digits.startsWith("0")) {
    return `234${digits.slice(1)}`;
  }
  return digits;
}

function resolveChromeExecutable(): string | undefined {
  if (process.env.CHROME_BIN) return process.env.CHROME_BIN;
  try {
    const command = process.platform === "win32" ? "where" : "which";
    const discovered = execFileSync(command, ["chromium"], {
      encoding: "utf8",
    }).trim().split(/\r?\n/)[0];
    return discovered || undefined;
  } catch {
    return undefined;
  }
}

function resolveAuthDataPath(): string {
  return path.resolve(process.cwd(), process.env.WHATSAPP_AUTH_DIR ?? ".wwebjs_auth");
}

function stopOrphanedBrowserProcesses(authDataPath: string): void {
  const sessionPath = path.join(authDataPath, "session");
  try {
    const processes = execFileSync("ps", ["-eo", "pid=,args="], {
      encoding: "utf8",
    });

    for (const line of processes.split("\n")) {
      const match = line.trim().match(/^(\d+)\s+(.*)$/);
      if (!match || !match[2].includes(`--user-data-dir=${sessionPath}`)) continue;

      const pid = Number(match[1]);
      if (!Number.isInteger(pid) || pid === process.pid) continue;
      try {
        process.kill(pid, "SIGTERM");
      } catch {
        // The process may have exited between ps and kill.
      }
    }
  } catch {
    // Process cleanup is best effort; Chromium will report a useful error if
    // another live instance still owns the profile.
  }
}

function newEvent(
  type: WhatsappEventType,
  message: string,
  detail?: string | null,
): WhatsappEvent {
  return {
    id: `${Date.now()}-${randomInt(1000, 9999)}`,
    type,
    message,
    detail: detail ?? null,
    createdAt: new Date().toISOString(),
  };
}

class WhatsappAutomationService {
  private client: WhatsappClient | null = null;
  private state: WhatsappState = "idle";
  private qrDataUrl: string | null = null;
  private pairingCode: string | null = null;
  private pairingPhoneNumber: string | null = null;
  private pendingPhoneNumber: string | null = null;
  private account: string | null = null;
  private device: string | null = null;
  private lastError: string | null = null;
  private lastConnectedAt: string | null = null;
  private readySince: number | null = null;
  private presenceTimer: NodeJS.Timeout | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private startPromise: Promise<void> | null = null;
  private events: WhatsappEvent[] = [];
  private settings: WhatsappSettings = { ...DEFAULT_SETTINGS };
  private messagesRead = 0;
  private statusesReacted = 0;
  private reactedStatusIds = new Set<string>();
  private autoReplySentAt = new Map<string, number>();

  constructor() {
    this.log("info", "WhatsApp worker is ready to start");
  }

  start(): Promise<void> {
    if (this.startPromise) return this.startPromise;
    if (
      this.client &&
      ["initializing", "qr", "pairing_code", "authenticated", "ready"].includes(this.state)
    ) {
      return Promise.resolve();
    }

    this.startPromise = this.initialize().finally(() => {
      this.startPromise = null;
    });
    return this.startPromise;
  }

  /**
   * Start (or switch) the linking flow to phone-number pairing instead of a
   * QR scan. WhatsApp will show an 8-character code that the user types in
   * under: WhatsApp app -> Linked devices -> Link a device -> "Link with
   * phone number instead".
   */
  async requestPhonePairing(rawPhoneNumber: string): Promise<void> {
    const phoneNumber = normalizePairingPhoneNumber(rawPhoneNumber);
    if (phoneNumber.length < 7 || phoneNumber.length > 15) {
      throw new Error(
        "Enter a valid phone number with country code, for example 2348012345678.",
      );
    }

    this.pendingPhoneNumber = phoneNumber;
    this.pairingCode = null;
    this.pairingPhoneNumber = null;
    this.qrDataUrl = null;
    this.log("info", "Requesting a WhatsApp pairing code", `for +${phoneNumber}`);

    // Pairing must be selected when the WhatsApp Web client starts. Calling
    // requestPairingCode after the QR flow has already started can leave the
    // Puppeteer target stuck or closed.
    if (this.client) {
      await this.stopClient(this.client);
    }

    this.state = "idle";
    await this.start();
  }

  /** Switch back to QR-code linking if the user started a phone pairing flow. */
  async useQrCode(): Promise<void> {
    this.pendingPhoneNumber = null;
    this.pairingCode = null;
    this.pairingPhoneNumber = null;
    this.qrDataUrl = null;
    if (this.client) {
      await this.stopClient(this.client);
    }
    this.state = "idle";
    await this.start();
  }

  private async initialize(): Promise<void> {
    this.clearReconnectTimer();
    this.clearPresenceTimer();
    stopOrphanedBrowserProcesses(resolveAuthDataPath());
    this.state = "initializing";
    this.qrDataUrl = null;
    this.pairingCode = null;
    this.lastError = null;
    this.log("info", "Starting WhatsApp Web client");

    const client = new Client({
      authStrategy: new LocalAuth({
        dataPath: process.env.WHATSAPP_AUTH_DIR ?? ".wwebjs_auth",
      }),
      ...(this.pendingPhoneNumber
        ? {
            pairWithPhoneNumber: {
              phoneNumber: this.pendingPhoneNumber,
              showNotification: true,
            },
          }
        : {}),
      puppeteer: {
        headless: true,
        executablePath: resolveChromeExecutable(),
        protocolTimeout: 120_000,
        timeout: 120_000,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-gpu",
          "--no-first-run",
        ],
      },
    });

    this.client = client;
    this.registerHandlers(client);

    try {
      await client.initialize();
    } catch (error) {
      this.fail("Failed to initialize WhatsApp Web client", error);
    }
  }

  private registerHandlers(client: WhatsappClient): void {
    client.on("code", (code: string) => {
      if (this.client !== client) return;
      this.pairingCode = code;
      this.pairingPhoneNumber = this.pendingPhoneNumber;
      this.qrDataUrl = null;
      this.state = "pairing_code";
      this.log("pairing_code", "Pairing code ready — enter it on your phone", code);
    });

    client.on("qr", async (qr) => {
      if (this.client !== client) return;
      try {
        this.qrDataUrl = await QRCode.toDataURL(qr, {
          margin: 1,
          width: 320,
          color: { dark: "#13231c", light: "#ffffff" },
        });
        this.state = "qr";
        this.log("qr", "New QR code is ready to scan");
      } catch (error) {
        this.fail("Could not generate QR code", error);
      }
    });

    client.on("authenticated", () => {
      if (this.client !== client) return;
      this.state = "authenticated";
      this.qrDataUrl = null;
      this.pairingCode = null;
      this.pendingPhoneNumber = null;
      this.log("connected", "WhatsApp session authenticated");
    });

    client.on("ready", () => {
      if (this.client !== client) return;
      this.state = "ready";
      this.lastError = null;
      this.readySince = Date.now();
      this.lastConnectedAt = new Date().toISOString();
      this.account = client.info?.wid?.user ? `${client.info.wid.user}@c.us` : null;
      this.device = client.info?.platform ?? null;
      this.log("connected", "WhatsApp client is ready for automation", this.account);
      void this.markUnreadChatsAsRead(client);
      void this.reactToRecentStatuses(client);
      void this.sendPresence();
      this.presenceTimer = setInterval(() => void this.sendPresence(), 15 * 60 * 1000);
    });

    client.on("message", (message) => {
      void this.handleIncomingMessage(message);
    });

    // Fires when someone new joins a group the linked account is in.
    client.on("group_join", async (notification: any) => {
      if (!this.settings.welcomeNewMembers) return;
      try {
        const joinedId: string | undefined =
          notification?.recipientIds?.[0] ?? notification?.id?.participant;
        if (!joinedId || this.isIgnored(joinedId)) return;
        const text = this.settings.welcomeMessage?.trim() || DEFAULT_SETTINGS.welcomeMessage;
        if (typeof notification.reply === "function") {
          await notification.reply(text);
        }
        this.log("member_joined", "Sent a welcome message to a new group member", joinedId);
      } catch (error) {
        this.log("warning", "Could not send a welcome message", asErrorMessage(error));
      }
    });

    client.on("auth_failure", (message) => {
      if (this.client !== client) return;
      this.state = "auth_failure";
      this.lastError = message;
      this.pairingCode = null;
      this.pendingPhoneNumber = null;
      this.log("error", "WhatsApp authentication failed", message);
    });

    client.on("disconnected", (reason) => {
      if (this.client !== client) return;
      this.state = "disconnected";
      this.readySince = null;
      this.clearPresenceTimer();
      this.log("warning", "WhatsApp client disconnected; retrying", reason);
      this.scheduleReconnect();
    });
  }

  private isIgnored(id: string): boolean {
    const digits = normalizeDigits(id);
    if (!digits) return false;
    return this.settings.ignoredNumbers.some((entry) => {
      const needle = normalizeDigits(entry);
      return needle.length > 0 && digits.includes(needle);
    });
  }

  private async handleIncomingMessage(message: Message): Promise<void> {
    if (message.from === "status@broadcast") {
      await this.handleStatus(message);
      return;
    }

    if (message.fromMe) return;
    if (this.isIgnored(message.from)) return;

    // Read and react are independent actions. Do not let command/auto-reply
    // handling short-circuit either passive automation.
    const actions: Promise<unknown>[] = [];

    if (this.settings.autoRead) {
      actions.push(this.markChatAsRead(message.from));
    }

    if (this.settings.autoReactMessages) {
      actions.push(this.reactToMessage(message));
    }

    // Run passive actions concurrently so a slow WhatsApp operation does not
    // block the other one from being scheduled.
    await Promise.allSettled(actions);

    if (this.settings.commandsEnabled) {
      const handled = await this.handleCommand(message);
      if (handled) return;
    }

    if (this.settings.autoReply) {
      await this.maybeAutoReply(message);
    }
  }



  /** React to every incoming non-status message after a randomized delay. */
  private async reactToMessage(message: Message): Promise<void> {
    const min = Math.max(1, Math.min(10, this.settings.randomDelayMin));
    const max = Math.max(min, Math.min(10, this.settings.randomDelayMax));
    const delaySeconds = randomInt(min, max + 1);

    this.log(
      "info",
      "Incoming message detected; reaction scheduled",
      `${delaySeconds}s delay`,
    );

    await new Promise((resolve) => setTimeout(resolve, delaySeconds * 1000));

    if (!this.client || this.state !== "ready") return;

    try {
      await message.react("👍");
      this.log(
        "message_reacted",
        "Message reacted to",
        `👍 after ${delaySeconds}s`,
      );
    } catch (error) {
      this.log(
        "warning",
        "Message was detected but could not be reacted to",
        asErrorMessage(error),
      );
    }
  }

  private async markChatAsRead(chatId: string): Promise<void> {
    if (!this.client || this.state !== "ready") return;
    try {
      await this.client.sendSeen(chatId);
      this.messagesRead += 1;
      this.log("message_read", "Conversation marked as read", chatId);
    } catch (error) {
      this.log("warning", "Could not mark conversation as read", asErrorMessage(error));
    }
  }

  private async markUnreadChatsAsRead(client: WhatsappClient): Promise<void> {
    if (!this.settings.autoRead || this.client !== client) return;
    try {
      const chats = await this.getChatSummaries(client);
      for (const chat of chats) {
        if (this.client !== client || this.state !== "ready") return;
        if (chat.id === "status@broadcast" || !chat.unreadCount) continue;
        try {
          await client.sendSeen(chat.id);
          this.messagesRead += chat.unreadCount;
          this.log("message_read", "Existing conversation marked as read", chat.id);
        } catch (error) {
          this.log("warning", "Could not mark an existing conversation as read", asErrorMessage(error));
        }
      }
    } catch (error) {
      this.log("warning", "Could not mark existing unread chats as read", asErrorMessage(error));
    }
  }

  /** Simple, extensible "!command" handler. Add more entries to `replies` for more functions. */
  private async handleCommand(message: Message): Promise<boolean> {
    const body = message.body?.trim();
    if (!body || !body.startsWith("!")) return false;

    const [rawCommand] = body.slice(1).split(/\s+/);
    const command = rawCommand?.toLowerCase();
    if (!command) return false;

    const replies: Record<string, () => string> = {
      ping: () => "pong 🏓",
      time: () => `Server time: ${new Date().toLocaleString()}`,
      help: () => "Available commands: !ping, !time, !help",
    };

    const handler = replies[command];
    if (!handler) return false;

    try {
      await message.reply(handler());
      this.log("command_replied", "Replied to a command", `!${command} from ${message.from}`);
    } catch (error) {
      this.log("warning", "Could not reply to a command", asErrorMessage(error));
    }
    return true;
  }

  /** Sends an away/auto-reply message to direct chats, at most once per hour per chat. */
  private async maybeAutoReply(message: Message): Promise<void> {
    const chat = await message.getChat().catch(() => null);
    if (!chat || chat.isGroup) return;

    const last = this.autoReplySentAt.get(message.from) ?? 0;
    if (Date.now() - last < AUTO_REPLY_COOLDOWN_MS) return;

    try {
      await message.reply(this.settings.autoReplyMessage?.trim() || DEFAULT_SETTINGS.autoReplyMessage);
      this.autoReplySentAt.set(message.from, Date.now());
      this.log("auto_replied", "Sent an automatic reply", message.from);
    } catch (error) {
      this.log("warning", "Could not send an automatic reply", asErrorMessage(error));
    }
  }

  private async handleStatus(message: Message): Promise<void> {
    if (!this.settings.autoReactStatus || message.fromMe) return;

    const statusId = message.id?._serialized ?? message.id?.id;
    if (statusId && this.reactedStatusIds.has(statusId)) return;
    if (statusId) {
      this.reactedStatusIds.add(statusId);
      if (this.reactedStatusIds.size > 500) {
        const oldest = this.reactedStatusIds.values().next().value;
        if (oldest) this.reactedStatusIds.delete(oldest);
      }
    }

    const min = this.settings.randomDelayMin;
    const max = this.settings.randomDelayMax;
    const delaySeconds = randomInt(min, max + 1);
    this.log(
      "info",
      "New status detected; reaction scheduled",
      `${delaySeconds}s delay`,
    );

    await new Promise((resolve) => setTimeout(resolve, delaySeconds * 1000));

    try {
      await message.react("👍");
      this.statusesReacted += 1;
      this.log(
        "status_reacted",
        "Status viewed and reacted to",
        `👍 after ${delaySeconds}s`,
      );
    } catch (error) {
      this.log(
        "warning",
        "Status was detected but could not be reacted to",
        asErrorMessage(error),
      );
    }
  }

  private async reactToRecentStatuses(client: WhatsappClient): Promise<void> {
    if (!this.settings.autoReactStatus || this.client !== client) return;
    try {
      const statusChat = await client.getChatById("status@broadcast");
      const messages = await statusChat.fetchMessages({ limit: 50 });
      for (const message of messages) {
        if (this.client !== client || this.state !== "ready") return;
        await this.handleStatus(message);
      }
    } catch (error) {
      this.log("warning", "Could not load recent Status updates", asErrorMessage(error));
    }
  }

  async getChats(limit = 50): Promise<WhatsappChat[]> {
    if (!this.client || this.state !== "ready") return [];
    const chats = await this.getChatSummaries(this.client);
    return chats
      .filter((chat) => chat.id !== "status@broadcast")
      .slice(0, limit)
      .map((chat) => ({
        id: chat.id,
        name: chat.name,
        isGroup: chat.isGroup,
        unreadCount: chat.unreadCount,
        lastMessageAt: chat.timestamp ? new Date(chat.timestamp * 1000).toISOString() : null,
        lastMessage: chat.lastMessage,
      }));
  }

  private async getChatSummaries(client: WhatsappClient): Promise<WhatsappChatSummary[]> {
    if (!client.pupPage) return [];
    return client.pupPage.evaluate(() => {
      const pageWindow = globalThis as typeof globalThis & {
        require: (moduleName: string) => {
          Chat: { getModelsArray: () => Array<Record<string, any>> };
        };
      };
      const models = pageWindow.require("WAWebCollections").Chat.getModelsArray();
      return models.flatMap((chat: Record<string, any>) => {
        try {
          const id =
            chat.id?._serialized ??
            chat.id?.serialized ??
            (chat.id?.user && chat.id?.server ? `${chat.id.user}@${chat.id.server}` : "");
          if (!id) return [];
          return [{
            id,
            name: chat.formattedTitle ?? chat.name ?? id,
            isGroup: Boolean(chat.isGroup),
            unreadCount: Number(chat.unreadCount ?? 0),
            timestamp: typeof chat.t === "number" ? chat.t : null,
            lastMessage: typeof chat.lastMessage?.body === "string" ? chat.lastMessage.body : null,
          }];
        } catch {
          return [];
        }
      });
    });
  }

  async getChatMessages(chatId: string, limit = 50): Promise<WhatsappChatMessage[]> {
    if (!this.client || this.state !== "ready") return [];
    if (!this.client.pupPage) return [];
    return this.client.pupPage.evaluate(async (selectedChatId, messageLimit) => {
      const pageWindow = globalThis as typeof globalThis & {
        require: (moduleName: string) => any;
        WWebJS: { getMessageModel: (message: Record<string, any>) => Record<string, any> };
      };
      const wid = pageWindow.require("WAWebWidFactory").createWid(selectedChatId);
      const chat = pageWindow.require("WAWebCollections").Chat.get(wid);
      if (!chat) return [];
      const messages = chat.msgs
        .getModelsArray()
        .filter((message: Record<string, any>) => !message.isNotification)
        .slice(-messageLimit);
      return messages.map((message: Record<string, any>) => {
        const id = message.id?._serialized ?? message.id?.serialized ?? String(message.id?.id ?? "");
        return {
          id,
          body: typeof message.body === "string" ? message.body : "",
          fromMe: Boolean(message.id?.fromMe ?? message.fromMe),
          author: message.author?._serialized ?? message.author ?? message.from?._serialized ?? message.from ?? null,
          timestamp: Number(message.t ?? message.timestamp ?? message.id?.t ?? 0),
        };
      });
    }, chatId, Math.min(100, Math.max(1, limit)));
  }

  async sendChatMessage(chatId: string, body: string): Promise<WhatsappChatMessage> {
    if (!this.client || this.state !== "ready") {
      throw new Error("Link a WhatsApp account before sending messages");
    }
    const text = body.trim();
    if (!text) throw new Error("Message cannot be empty");
    if (!this.client.pupPage) throw new Error("WhatsApp Web is still loading");
    const message = await this.client.pupPage.evaluate(async (selectedChatId, content) => {
      const pageWindow = globalThis as typeof globalThis & {
        require: (moduleName: string) => any;
        WWebJS: {
          sendSeen: (chatId: string) => Promise<void>;
          sendMessage: (chat: Record<string, any>, body: string, options: Record<string, any>) => Promise<Record<string, any> | null>;
          getMessageModel: (message: Record<string, any>) => Record<string, any>;
        };
      };
      const wid = pageWindow.require("WAWebWidFactory").createWid(selectedChatId);
      const chat =
        pageWindow.require("WAWebCollections").Chat.get(wid) ??
        (await pageWindow.require("WAWebFindChatAction").findOrCreateLatestChat(wid))?.chat;
      if (!chat) throw new Error("Chat could not be found");
      await pageWindow.WWebJS.sendSeen(selectedChatId);
      const sent = await pageWindow.WWebJS.sendMessage(chat, content, {});
      return sent ? pageWindow.WWebJS.getMessageModel(sent) : null;
    }, chatId, text);
    if (!message) throw new Error("WhatsApp did not accept the message");
    return {
      id: message.id?._serialized ?? message.id?.serialized ?? String(message.id?.id ?? ""),
      body: message.body ?? text,
      fromMe: true,
      author: message.author ?? message.from ?? null,
      timestamp: Number(message.t ?? message.timestamp ?? 0),
    };
  }

  private async sendPresence(): Promise<void> {
    if (!this.settings.keepPresenceOnline || this.state !== "ready" || !this.client) {
      return;
    }

    try {
      const presenceClient = this.client as WhatsappClient & {
        sendPresenceAvailable?: () => Promise<void>;
      };
      if (presenceClient.sendPresenceAvailable) {
        await presenceClient.sendPresenceAvailable();
        this.log("info", "Presence refreshed as available");
      } else {
        this.log("warning", "This WhatsApp Web client version cannot refresh presence");
      }
    } catch (error) {
      this.log("warning", "Could not refresh online presence", asErrorMessage(error));
    }
  }

  async logout(): Promise<void> {
    this.clearReconnectTimer();
    this.clearPresenceTimer();
    const client = this.client;
    this.client = null;

    if (client) {
      try {
        await client.logout();
      } catch (error) {
        logger.warn({ err: error }, "WhatsApp logout returned an error");
      }
      try {
        await client.destroy();
      } catch (error) {
        logger.warn({ err: error }, "WhatsApp client destroy returned an error");
      }
    }

    this.state = "idle";
    this.qrDataUrl = null;
    this.pairingCode = null;
    this.pairingPhoneNumber = null;
    this.pendingPhoneNumber = null;
    this.account = null;
    this.device = null;
    this.lastError = null;
    this.readySince = null;
    this.autoReplySentAt.clear();
    this.log("info", "WhatsApp session logged out");
  }

  updateSettings(input: Partial<WhatsappSettings>): void {
    const next = { ...this.settings, ...input };
    if (next.randomDelayMin > next.randomDelayMax) {
      throw new Error("Minimum delay cannot be greater than maximum delay");
    }
    if (!Array.isArray(next.ignoredNumbers)) {
      next.ignoredNumbers = [];
    }
    this.settings = next;
    this.log("info", "Automation settings updated");
    if (this.state === "ready") void this.sendPresence();
  }

  getSnapshot(): WhatsappSnapshot {
    const uptimeSeconds =
      this.readySince === null ? 0 : Math.max(0, Math.floor((Date.now() - this.readySince) / 1000));
    return {
      state: this.state,
      ready: this.state === "ready",
      qrDataUrl: this.qrDataUrl,
      pairingCode: this.pairingCode,
      pairingPhoneNumber: this.pairingPhoneNumber,
      account: this.account,
      device: this.device,
      lastError: this.lastError,
      lastConnectedAt: this.lastConnectedAt,
      settings: { ...this.settings },
      events: this.events.slice(0, 30),
      metrics: {
        messagesRead: this.messagesRead,
        statusesReacted: this.statusesReacted,
        uptimeSeconds,
      },
    };
  }

  getEvents(limit: number): WhatsappEvent[] {
    return this.events.slice(0, limit);
  }

  private fail(message: string, error: unknown): void {
    const detail = asErrorMessage(error);
    const failedClient = this.client;
    this.client = null;
    this.clearPresenceTimer();
    if (failedClient) {
      void failedClient.destroy().catch((destroyError) => {
        logger.warn({ err: destroyError }, "Could not destroy failed WhatsApp client");
      });
    }
    this.state = "error";
    this.lastError = detail;
    this.log("error", message, detail);
    this.scheduleReconnect();
  }

  private async stopClient(client: WhatsappClient): Promise<void> {
    if (this.client === client) {
      this.client = null;
    }
    this.clearPresenceTimer();
    try {
      await client.destroy();
    } catch (error) {
      logger.warn({ err: error }, "Could not stop WhatsApp client cleanly");
    }
  }

  private log(type: WhatsappEventType, message: string, detail?: string | null): void {
    const event = newEvent(type, message, detail);
    this.events = [event, ...this.events].slice(0, MAX_EVENTS);
    if (type === "error") logger.error({ detail: event.detail }, event.message);
    else if (type === "warning") logger.warn({ detail: event.detail }, event.message);
    else logger.info({ detail: event.detail }, event.message);
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer || this.state === "idle") return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.start();
    }, 5_000);
  }

  private clearPresenceTimer(): void {
    if (this.presenceTimer) clearInterval(this.presenceTimer);
    this.presenceTimer = null;
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
  }
}

export const whatsappAutomation = new WhatsappAutomationService();
void whatsappAutomation.start();
