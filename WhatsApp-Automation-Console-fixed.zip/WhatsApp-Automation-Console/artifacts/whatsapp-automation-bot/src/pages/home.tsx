import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Clock3,
  Copy,
  Eye,
  EyeOff,
  Link2,
  LoaderCircle,
  LogOut,
  MessageCircle,
  MessageSquare,
  Phone,
  QrCode,
  RefreshCcw,
  ShieldCheck,
  Send,
  Search,
  Smartphone,
  Terminal,
  UserRound,
  Users,
  Wifi,
  XCircle,
  Zap,
} from 'lucide-react';
import {
  getGetWhatsappStatusQueryKey,
  getHealthCheckQueryKey,
  getListWhatsappEventsQueryKey,
  useGetWhatsappStatus,
  useHealthCheck,
  getListWhatsappChatMessagesQueryKey,
  getListWhatsappChatsQueryKey,
  useListWhatsappEvents,
  useListWhatsappChatMessages,
  useListWhatsappChats,
  useLogoutWhatsapp,
  usePairWhatsapp,
  useStartWhatsapp,
  useUpdateWhatsappSettings,
  useUseQrWhatsapp,
  useSendWhatsappChatMessage,
  type WhatsappEvent,
  type WhatsappChat,
  type WhatsappChatMessage,
  type WhatsappSettings,
  type WhatsappStatus,
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';

const eventsParams = { limit: 12 };

type SettingsState = {
  autoRead: boolean;
  autoReactMessages: boolean;
  autoReactStatus: boolean;
  keepPresenceOnline: boolean;
  randomDelayMin: number;
  randomDelayMax: number;
  commandsEnabled: boolean;
  autoReply: boolean;
  autoReplyMessage: string;
  welcomeNewMembers: boolean;
  welcomeMessage: string;
  ignoredNumbers: string[];
};

const defaults: SettingsState = {
  autoRead: true,
  autoReactMessages: true,
  autoReactStatus: false,
  keepPresenceOnline: true,
  randomDelayMin: 2,
  randomDelayMax: 5,
  commandsEnabled: true,
  autoReply: false,
  autoReplyMessage: 'I am away right now. I will get back to you soon.',
  welcomeNewMembers: false,
  welcomeMessage: 'Welcome to the group.',
  ignoredNumbers: [],
};

function normalizeSettings(settings?: WhatsappSettings): SettingsState {
  return {
    autoRead: settings?.autoRead ?? defaults.autoRead,
    autoReactMessages: settings?.autoReactMessages ?? defaults.autoReactMessages,
    autoReactStatus: settings?.autoReactStatus ?? defaults.autoReactStatus,
    keepPresenceOnline: settings?.keepPresenceOnline ?? defaults.keepPresenceOnline,
    randomDelayMin: settings?.randomDelayMin ?? defaults.randomDelayMin,
    randomDelayMax: settings?.randomDelayMax ?? defaults.randomDelayMax,
    commandsEnabled: settings?.commandsEnabled ?? defaults.commandsEnabled,
    autoReply: settings?.autoReply ?? defaults.autoReply,
    autoReplyMessage: settings?.autoReplyMessage ?? defaults.autoReplyMessage,
    welcomeNewMembers: settings?.welcomeNewMembers ?? defaults.welcomeNewMembers,
    welcomeMessage: settings?.welcomeMessage ?? defaults.welcomeMessage,
    ignoredNumbers: settings?.ignoredNumbers ?? defaults.ignoredNumbers,
  };
}

function formatDuration(seconds?: number) {
  if (!seconds) return '—';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days) return `${days}d ${hours}h`;
  if (hours) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

function formatTime(value?: string | null) {
  if (!value) return 'Not yet';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Unknown';
  return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(date);
}

function formatDateTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

function stateLabel(state?: WhatsappStatus['state']) {
  const labels: Record<string, string> = {
    idle: 'Not linked',
    initializing: 'Starting client',
    qr: 'Awaiting QR scan',
    pairing_code: 'Awaiting phone pairing',
    authenticated: 'Authenticated',
    ready: 'Connected',
    disconnected: 'Disconnected',
    auth_failure: 'Authentication failed',
    error: 'Needs attention',
  };
  return labels[state ?? 'idle'] ?? 'Unknown state';
}

function stateTone(state?: WhatsappStatus['state']) {
  if (state === 'ready') return 'ready';
  if (state === 'error' || state === 'auth_failure') return 'error';
  if (state === 'disconnected' || state === 'idle') return 'quiet';
  return 'working';
}

function eventTone(type: WhatsappEvent['type']) {
  if (type === 'error' || type === 'warning') return 'warning';
  if (type === 'connected' || type === 'info') return 'success';
  return 'neutral';
}

function EventIcon({ type }: { type: WhatsappEvent['type'] }) {
  if (type === 'message_read') return <Eye className="h-4 w-4" />;
  if (type === 'status_reacted') return <Zap className="h-4 w-4" />;
  if (type === 'command_replied') return <Terminal className="h-4 w-4" />;
  if (type === 'auto_replied') return <MessageCircle className="h-4 w-4" />;
  if (type === 'member_joined') return <Users className="h-4 w-4" />;
  if (type === 'connected') return <Wifi className="h-4 w-4" />;
  if (type === 'error' || type === 'warning') return <AlertTriangle className="h-4 w-4" />;
  return <Activity className="h-4 w-4" />;
}

function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-[hsl(var(--muted))] ${className}`} />;
}

function Toggle({
  checked,
  onChange,
  label,
  description,
  testId,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description: string;
  testId: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={checked}
      data-testid={testId}
      onClick={() => onChange(!checked)}
      className="group flex w-full items-center justify-between gap-4 border-b border-[hsl(var(--border))] py-4 text-left transition-colors last:border-b-0 hover:bg-[hsl(var(--muted)/.32)]"
    >
      <span className="min-w-0">
        <span className="block text-[13px] font-semibold text-[hsl(var(--foreground))]">{label}</span>
        <span className="mt-0.5 block text-[11px] leading-4 text-[hsl(var(--muted-foreground))]">{description}</span>
      </span>
      <span
        className={`relative h-6 w-11 shrink-0 rounded-full p-1 transition-colors ${
          checked ? 'bg-[hsl(var(--primary))]' : 'bg-[hsl(var(--muted-foreground)/.28)]'
        }`}
      >
        <span
          className={`block h-4 w-4 rounded-full bg-[hsl(var(--card))] shadow-sm transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </span>
    </button>
  );
}

function SectionHeading({
  eyebrow,
  title,
  detail,
  action,
}: {
  eyebrow: string;
  title: string;
  detail?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-5 flex items-start justify-between gap-4">
      <div>
        <p className="font-mono-ui text-[10px] font-medium uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">
          {eyebrow}
        </p>
        <h2 className="mt-1 text-[20px] font-bold tracking-[-0.03em] text-[hsl(var(--foreground))]">{title}</h2>
        {detail && <p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{detail}</p>}
      </div>
      {action}
    </div>
  );
}

function BrandMark() {
  return (
    <div className="relative flex h-9 w-9 items-center justify-center rounded-[11px] bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]">
      <MessageCircle className="h-[18px] w-[18px]" strokeWidth={2.2} />
      <span className="absolute bottom-[7px] right-[6px] h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar))]" />
    </div>
  );
}

function ConnectionCard({
  status,
  isWorking,
  onStart,
  onLogout,
  onUseQr,
  onPair,
  pairPhone,
  setPairPhone,
  pairError,
  pairPending,
}: {
  status?: WhatsappStatus;
  isWorking: boolean;
  onStart: () => void;
  onLogout: () => void;
  onUseQr: () => void;
  onPair: (event: FormEvent) => void;
  pairPhone: string;
  setPairPhone: (value: string) => void;
  pairError: string;
  pairPending: boolean;
}) {
  const tone = stateTone(status?.state);
  const waitingForQr = status?.state === 'qr' || Boolean(status?.qrDataUrl);
  const waitingForPair = status?.state === 'pairing_code';
  const ready = status?.ready || status?.state === 'ready';

  return (
    <section
      data-testid="card-connection"
      className="relative overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[var(--shadow-sm)]"
    >
      <div className="absolute right-0 top-0 h-32 w-32 rounded-full bg-[hsl(var(--secondary)/.45)] blur-3xl" />
      <div className="relative flex flex-col gap-5 p-5 sm:p-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-start gap-4">
          <div
            className={`relative mt-0.5 flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
              tone === 'ready'
                ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]'
                : tone === 'error'
                  ? 'bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]'
                  : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'
            }`}
          >
            {ready ? <ShieldCheck className="h-6 w-6" /> : <Link2 className="h-6 w-6" />}
            {ready && <span className="animate-pulse-soft absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-[hsl(var(--card))] bg-[hsl(var(--primary))]" />}
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-bold tracking-[-0.03em] text-[hsl(var(--foreground))]">
                {ready ? 'Your account is connected' : 'Link your WhatsApp account'}
              </h2>
              <span
                data-testid="status-connection-state"
                className={`rounded-full px-2 py-1 font-mono-ui text-[10px] font-medium uppercase tracking-wide ${
                  tone === 'ready'
                    ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]'
                    : tone === 'error'
                      ? 'bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]'
                      : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'
                }`}
              >
                {stateLabel(status?.state)}
              </span>
            </div>
            <p data-testid="text-connection-detail" className="mt-1 max-w-xl text-sm leading-5 text-[hsl(var(--muted-foreground))]">
              {ready
                ? `${status?.account ?? 'Personal account'} is being watched from this private console.`
                : 'Choose QR linking or use a phone pairing code. Nothing runs until you approve the session.'}
            </p>
            {status?.lastError && (
              <p data-testid="text-connection-error" className="mt-2 flex items-center gap-1.5 text-xs font-medium text-[hsl(var(--destructive))]">
                <AlertTriangle className="h-3.5 w-3.5" /> {status.lastError}
              </p>
            )}
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          {ready ? (
            <button
              type="button"
              data-testid="button-logout-whatsapp"
              onClick={onLogout}
              disabled={isWorking}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-[hsl(var(--border))] px-3.5 text-xs font-bold text-[hsl(var(--foreground))] transition-colors hover:bg-[hsl(var(--muted))] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isWorking ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />}
              Unlink account
            </button>
          ) : (
            <button
              type="button"
              data-testid="button-start-whatsapp"
              onClick={onStart}
              disabled={isWorking}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 text-xs font-bold text-[hsl(var(--primary-foreground))] transition-[transform,background-color] hover:-translate-y-0.5 hover:bg-[hsl(var(--primary)/.9)] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isWorking ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
              Start linking
            </button>
          )}
        </div>
      </div>

      {!ready && (waitingForQr || waitingForPair || status?.state === 'initializing') && (
        <div className="relative border-t border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] p-5 sm:p-6">
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(300px,0.8fr)]">
            <div>
              <div className="mb-4 flex items-center gap-2">
                <span className="font-mono-ui text-[10px] font-medium uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">
                  {waitingForPair ? 'Phone pairing' : 'QR pairing'}
                </span>
                <span className="h-1 w-1 rounded-full bg-[hsl(var(--accent))]" />
                <span className="text-xs text-[hsl(var(--muted-foreground))]">
                  {status?.state === 'initializing' ? 'Preparing a secure session…' : 'Only visible to you'}
                </span>
              </div>
              {waitingForPair ? (
                <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5">
                  <p className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">Your pairing code</p>
                  <p data-testid="text-pairing-code" className="mt-2 font-mono-ui text-3xl font-medium tracking-[0.18em] text-[hsl(var(--foreground))]">
                    {status?.pairingCode ?? 'Waiting…'}
                  </p>
                  <p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">
                    On WhatsApp, open Linked devices → Link a device → Link with phone number instead.
                  </p>
                  <button
                    type="button"
                    data-testid="button-copy-pairing-code"
                    onClick={() => status?.pairingCode && navigator.clipboard?.writeText(status.pairingCode)}
                    disabled={!status?.pairingCode}
                    className="mt-4 inline-flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-xs font-bold transition-colors hover:bg-[hsl(var(--muted))] disabled:opacity-40"
                  >
                    <Copy className="h-3.5 w-3.5" /> Copy code
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-4 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 sm:flex-row">
                  <div className="flex h-40 w-40 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-2">
                    {status?.qrDataUrl ? (
                      <img data-testid="img-whatsapp-qr" src={status.qrDataUrl} alt="WhatsApp account linking QR code" className="h-full w-full object-contain" />
                    ) : (
                      <div data-testid="status-qr-loading" className="flex flex-col items-center gap-2 text-center text-[hsl(var(--muted-foreground))]">
                        <LoaderCircle className="h-7 w-7 animate-spin text-[hsl(var(--primary))]" />
                        <span className="text-[10px] font-semibold">Generating a private QR</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[hsl(var(--foreground))]">Scan from your phone</p>
                    <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">
                      WhatsApp → Settings → Linked devices → Link a device. This code refreshes automatically.
                    </p>
                    <button
                      type="button"
                      data-testid="button-switch-to-pairing"
                      onClick={onPair}
                      className="mt-4 text-xs font-bold text-[hsl(var(--primary))] underline decoration-[hsl(var(--primary)/.3)] underline-offset-4 transition-colors hover:text-[hsl(var(--foreground))]"
                    >
                      Use a phone number instead
                    </button>
                  </div>
                </div>
              )}
            </div>
            <form onSubmit={onPair} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-[hsl(var(--primary))]" />
                <p className="text-sm font-bold text-[hsl(var(--foreground))]">Pair by phone</p>
              </div>
              <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Digits only, including country code.</p>
              <label htmlFor="pair-phone" className="sr-only">Phone number</label>
              <input
                id="pair-phone"
                data-testid="input-pair-phone"
                value={pairPhone}
                onChange={(event) => setPairPhone(event.target.value.replace(/[^\d]/g, ''))}
                placeholder="2348012345678"
                inputMode="numeric"
                className="mt-4 h-10 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 font-mono-ui text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.55)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--ring)/.16)]"
              />
              {pairError && <p data-testid="text-pair-error" className="mt-2 text-xs text-[hsl(var(--destructive))]">{pairError}</p>}
              <button
                type="submit"
                data-testid="button-request-pairing-code"
                disabled={pairPending || pairPhone.length < 7}
                className="mt-3 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-[hsl(var(--primary))] text-xs font-bold text-[hsl(var(--primary-foreground))] transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45"
              >
                {pairPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Smartphone className="h-4 w-4" />}
                Request pairing code
              </button>
              {waitingForPair && (
                <button
                  type="button"
                  data-testid="button-switch-to-qr"
                  onClick={onUseQr}
                  className="mt-3 inline-flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-[hsl(var(--border))] text-xs font-bold text-[hsl(var(--foreground))] transition-colors hover:bg-[hsl(var(--muted))]"
                >
                  <QrCode className="h-3.5 w-3.5" /> Switch to QR
                </button>
              )}
            </form>
          </div>
        </div>
      )}
    </section>
  );
}

function ChatsSection({
  chats,
  chatsLoading,
  messages,
  messagesLoading,
  selectedChatId,
  onSelectChat,
  draft,
  setDraft,
  onSend,
  sending,
}: {
  chats: WhatsappChat[];
  chatsLoading: boolean;
  messages: WhatsappChatMessage[];
  messagesLoading: boolean;
  selectedChatId: string;
  onSelectChat: (chatId: string) => void;
  draft: string;
  setDraft: (value: string) => void;
  onSend: (event: FormEvent) => void;
  sending: boolean;
}) {
  const [search, setSearch] = useState('');
  const selectedChat = chats.find((chat) => chat.id === selectedChatId);
  const visibleChats = chats.filter((chat) => chat.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <section data-testid="section-chats" className="animate-rise rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-2xs)] sm:p-6">
      <SectionHeading
        eyebrow="Conversation workspace"
        title="Chats"
        detail="Read imported conversations and reply from the linked session."
        action={<span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">{chats.length} loaded</span>}
      />
      <div className="grid min-h-[28rem] overflow-hidden rounded-xl border border-[hsl(var(--border))] lg:grid-cols-[minmax(220px,.72fr)_minmax(0,1.28fr)]">
        <div className="border-b border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] lg:border-b-0 lg:border-r">
          <div className="border-b border-[hsl(var(--border))] p-3">
            <label className="flex h-9 items-center gap-2 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-2.5 text-[hsl(var(--muted-foreground))]">
              <Search className="h-3.5 w-3.5" />
              <span className="sr-only">Search chats</span>
              <input
                data-testid="input-search-chats"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search chats"
                className="min-w-0 flex-1 bg-transparent text-xs text-[hsl(var(--foreground))] outline-none placeholder:text-[hsl(var(--muted-foreground)/.65)]"
              />
            </label>
          </div>
          <div className="max-h-[24rem] overflow-y-auto p-2">
            {chatsLoading ? (
              <div data-testid="state-chats-loading" className="space-y-2 p-1">
                <SkeletonBlock className="h-14 w-full" />
                <SkeletonBlock className="h-14 w-full" />
                <SkeletonBlock className="h-14 w-full" />
              </div>
            ) : visibleChats.length ? (
              visibleChats.map((chat) => (
                <button
                  type="button"
                  key={chat.id}
                  data-testid={`button-chat-${chat.id}`}
                  onClick={() => onSelectChat(chat.id)}
                  className={`mb-1 flex w-full items-start gap-3 rounded-lg p-3 text-left transition-colors ${
                    chat.id === selectedChatId
                      ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]'
                      : 'hover:bg-[hsl(var(--muted)/.55)]'
                  }`}
                >
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]">
                    {chat.isGroup ? <Users className="h-4 w-4" /> : <MessageSquare className="h-4 w-4" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-xs font-bold">{chat.name}</span>
                      {chat.unreadCount > 0 && <span className="rounded-full bg-[hsl(var(--accent))] px-1.5 py-0.5 font-mono-ui text-[9px] text-[hsl(var(--accent-foreground))]">{chat.unreadCount}</span>}
                    </span>
                    <span className="mt-1 block truncate text-[10px] text-[hsl(var(--muted-foreground))]">{chat.lastMessage || 'No messages yet'}</span>
                  </span>
                </button>
              ))
            ) : (
              <div data-testid="state-chats-empty" className="p-5 text-center text-xs text-[hsl(var(--muted-foreground))]">
                {chats.length ? 'No chats match your search.' : 'Link an account to import chats.'}
              </div>
            )}
          </div>
        </div>
        <div className="flex min-h-[28rem] min-w-0 flex-col bg-[hsl(var(--background)/.28)]">
          {selectedChat ? (
            <>
              <div className="flex items-center gap-3 border-b border-[hsl(var(--border))] bg-[hsl(var(--card))] px-4 py-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><MessageCircle className="h-4 w-4" /></span>
                <div className="min-w-0">
                  <p data-testid="text-selected-chat" className="truncate text-sm font-bold">{selectedChat.name}</p>
                  <p className="text-[10px] text-[hsl(var(--muted-foreground))]">{selectedChat.isGroup ? 'Group chat' : 'Direct chat'}</p>
                </div>
              </div>
              <div className="flex-1 space-y-2 overflow-y-auto p-4">
                {messagesLoading ? (
                  <div data-testid="state-messages-loading" className="space-y-3"><SkeletonBlock className="h-12 w-3/4" /><SkeletonBlock className="ml-auto h-12 w-2/3" /></div>
                ) : messages.length ? (
                  messages.map((message) => (
                    <div key={message.id} data-testid={`row-chat-message-${message.id}`} className={`flex ${message.fromMe ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[82%] rounded-2xl px-3 py-2 text-xs leading-5 ${message.fromMe ? 'rounded-br-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'rounded-bl-md bg-[hsl(var(--card))] text-[hsl(var(--foreground))] shadow-[var(--shadow-2xs)]'}`}>
                        <p className="whitespace-pre-wrap break-words">{message.body || 'Media message'}</p>
                        <p className={`mt-1 text-[9px] ${message.fromMe ? 'text-[hsl(var(--primary-foreground)/.6)]' : 'text-[hsl(var(--muted-foreground))]'}`}>{new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(message.timestamp * 1000))}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div data-testid="state-messages-empty" className="flex h-full min-h-48 items-center justify-center text-xs text-[hsl(var(--muted-foreground))]">No messages in this chat.</div>
                )}
              </div>
              <form onSubmit={onSend} className="flex gap-2 border-t border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3">
                <label className="sr-only" htmlFor="chat-message">Message</label>
                <input
                  id="chat-message"
                  data-testid="input-chat-message"
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  placeholder="Write a reply…"
                  className="h-10 min-w-0 flex-1 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 text-xs outline-none focus:border-[hsl(var(--primary))]"
                />
                <button type="submit" data-testid="button-send-chat-message" disabled={sending || !draft.trim()} className="inline-flex h-10 items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-3 text-xs font-bold text-[hsl(var(--primary-foreground))] disabled:cursor-not-allowed disabled:opacity-45">
                  {sending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  <span className="hidden sm:inline">Send</span>
                </button>
              </form>
            </>
          ) : (
            <div data-testid="state-chat-unselected" className="flex flex-1 flex-col items-center justify-center px-6 text-center text-[hsl(var(--muted-foreground))]">
              <MessageSquare className="h-8 w-8 opacity-40" />
              <p className="mt-3 text-sm font-bold text-[hsl(var(--foreground))]">Select a chat</p>
              <p className="mt-1 max-w-xs text-xs leading-5">Your WhatsApp conversations will appear here when the linked session is ready.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Home() {
  const queryClient = useQueryClient();
  const statusQuery = useGetWhatsappStatus({
    query: { queryKey: getGetWhatsappStatusQueryKey(), refetchInterval: 3000 },
  });
  const chatsQuery = useListWhatsappChats(
    { limit: 50 },
    { query: { queryKey: getListWhatsappChatsQueryKey({ limit: 50 }), refetchInterval: 5000 } },
  );
  const eventsQuery = useListWhatsappEvents(eventsParams, {
    query: { queryKey: getListWhatsappEventsQueryKey(eventsParams), refetchInterval: 5000 },
  });
  const healthQuery = useHealthCheck({
    query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 15000 },
  });
  const startWhatsapp = useStartWhatsapp();
  const logoutWhatsapp = useLogoutWhatsapp();
  const pairWhatsapp = usePairWhatsapp();
  const useQrWhatsapp = useUseQrWhatsapp();
  const updateWhatsappSettings = useUpdateWhatsappSettings();
  const sendChatMessage = useSendWhatsappChatMessage();

  const status = statusQuery.data;
  const ready = Boolean(status?.ready || status?.state === 'ready');
  const [pairPhone, setPairPhone] = useState('');
  const [pairError, setPairError] = useState('');
  const [settings, setSettings] = useState<SettingsState>(defaults);
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedChatId, setSelectedChatId] = useState('');
  const [chatDraft, setChatDraft] = useState('');

  useEffect(() => {
    if (status?.settings) setSettings(normalizeSettings(status.settings));
  }, [status?.settings]);

  const events = useMemo(() => eventsQuery.data ?? status?.events ?? [], [eventsQuery.data, status?.events]);
  const chats = chatsQuery.data ?? [];
  const chatMessagesQuery = useListWhatsappChatMessages(
    { chatId: selectedChatId, limit: 50 },
    {
      query: {
        queryKey: getListWhatsappChatMessagesQueryKey({ chatId: selectedChatId, limit: 50 }),
        enabled: Boolean(selectedChatId && ready),
        refetchInterval: 4000,
      },
    },
  );
  const working = startWhatsapp.isPending || logoutWhatsapp.isPending || useQrWhatsapp.isPending;
  const queryError = statusQuery.error || eventsQuery.error;

  const applyStatus = (next: WhatsappStatus) => {
    queryClient.setQueryData(getGetWhatsappStatusQueryKey(), next);
  };

  const handleStart = () => {
    setPairError('');
    startWhatsapp.mutate(undefined, { onSuccess: applyStatus });
  };

  const handleLogout = () => {
    if (!window.confirm('Unlink this WhatsApp session? Automation will stop immediately.')) return;
    logoutWhatsapp.mutate(undefined, { onSuccess: applyStatus });
  };

  const handlePair = (event: FormEvent) => {
    event.preventDefault();
    if (pairPhone.length < 7) {
      setPairError('Enter a valid number with country code.');
      return;
    }
    setPairError('');
    pairWhatsapp.mutate({ data: { phoneNumber: pairPhone } }, { onSuccess: applyStatus, onError: () => setPairError('Could not request a code. Try again.') });
  };

  const handleUseQr = () => {
    setPairError('');
    useQrWhatsapp.mutate(undefined, { onSuccess: applyStatus });
  };

  useEffect(() => {
    if (!chats.length) {
      setSelectedChatId('');
      return;
    }
    if (!selectedChatId || !chats.some((chat) => chat.id === selectedChatId)) {
      setSelectedChatId(chats[0].id);
    }
  }, [chats, selectedChatId]);

  const handleSendChatMessage = (event: FormEvent) => {
    event.preventDefault();
    const body = chatDraft.trim();
    if (!selectedChatId || !body) return;
    sendChatMessage.mutate(
      { data: { chatId: selectedChatId, body } },
      {
        onSuccess: () => {
          setChatDraft('');
          void queryClient.invalidateQueries({ queryKey: getListWhatsappChatMessagesQueryKey({ chatId: selectedChatId, limit: 50 }) });
          void queryClient.invalidateQueries({ queryKey: getListWhatsappChatsQueryKey({ limit: 50 }) });
        },
      },
    );
  };

  const updateSetting = <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => {
    const next = { ...settings, [key]: value };
    setSettings(next);
    setSettingsSaved(false);
    updateWhatsappSettings.mutate(
      { data: { [key]: value } },
      {
        onSuccess: (nextStatus) => {
          applyStatus(nextStatus);
          setSettingsSaved(true);
          window.setTimeout(() => setSettingsSaved(false), 1800);
        },
      },
    );
  };

  const saveMessage = () => {
    updateWhatsappSettings.mutate(
      {
        data: {
          autoReply: settings.autoReply,
          autoReplyMessage: settings.autoReplyMessage,
          welcomeNewMembers: settings.welcomeNewMembers,
          welcomeMessage: settings.welcomeMessage,
          ignoredNumbers: settings.ignoredNumbers,
        },
      },
      {
        onSuccess: (nextStatus) => {
          applyStatus(nextStatus);
          setSettingsSaved(true);
          window.setTimeout(() => setSettingsSaved(false), 1800);
        },
      },
    );
  };

  if (statusQuery.isLoading) {
    return (
      <div className="noise-layer min-h-[100dvh] bg-[hsl(var(--background))]">
        <div className="flex min-h-[100dvh]">
          <aside className="hidden w-[244px] shrink-0 bg-[hsl(var(--sidebar))] p-6 md:block">
            <SkeletonBlock className="h-9 w-32 bg-[hsl(var(--sidebar-accent))]" />
            <SkeletonBlock className="mt-14 h-9 w-full bg-[hsl(var(--sidebar-accent))]" />
            <SkeletonBlock className="mt-3 h-9 w-full bg-[hsl(var(--sidebar-accent))]" />
          </aside>
          <main className="w-full p-5 sm:p-8 lg:p-12">
            <SkeletonBlock className="h-8 w-48" />
            <SkeletonBlock className="mt-3 h-4 w-72" />
            <SkeletonBlock className="mt-10 h-40 w-full" />
            <div className="mt-5 grid gap-5 lg:grid-cols-3"><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /></div>
            <SkeletonBlock className="mt-5 h-80 w-full" />
          </main>
        </div>
      </div>
    );
  }

  if (queryError && !status) {
    return (
      <div className="noise-layer flex min-h-[100dvh] items-center justify-center bg-[hsl(var(--background))] p-6">
        <div data-testid="state-dashboard-error" className="w-full max-w-md rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-7 text-center shadow-[var(--shadow-lg)]">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]"><XCircle className="h-6 w-6" /></div>
          <h1 className="mt-5 text-xl font-bold">The console is offline</h1>
          <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">We could not read the WhatsApp session right now. The API may be waking up.</p>
          <button type="button" data-testid="button-retry-dashboard" onClick={() => statusQuery.refetch()} className="mt-6 inline-flex h-10 items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 text-xs font-bold text-[hsl(var(--primary-foreground))] hover:opacity-90"><RefreshCcw className="h-4 w-4" /> Try again</button>
        </div>
      </div>
    );
  }

  const safeStatus = status ?? {
    state: 'idle' as const,
    ready: false,
    qrDataUrl: null,
    account: null,
    settings: defaults,
    events: [],
    metrics: { messagesRead: 0, statusesReacted: 0, uptimeSeconds: 0 },
  };

  return (
    <div className="noise-layer min-h-[100dvh] bg-[hsl(var(--background))]">
      <div className="flex min-h-[100dvh]">
        <aside className="hidden w-[244px] shrink-0 flex-col bg-[hsl(var(--sidebar))] px-4 py-5 text-[hsl(var(--sidebar-foreground))] md:flex">
          <div className="flex items-center gap-3 px-2">
            <BrandMark />
            <div>
              <p className="text-sm font-extrabold tracking-[-0.03em]">quiet.link</p>
              <p className="font-mono-ui text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--sidebar-foreground)/.5)]">Private operations</p>
            </div>
          </div>
          <div className="mt-14">
            <p className="px-3 font-mono-ui text-[9px] uppercase tracking-[0.2em] text-[hsl(var(--sidebar-foreground)/.42)]">Workspace</p>
            <nav className="mt-3 space-y-1" aria-label="Main navigation">
              <a href="/" data-testid="link-overview" className="flex items-center gap-3 rounded-xl bg-[hsl(var(--sidebar-accent))] px-3 py-2.5 text-sm font-bold text-[hsl(var(--sidebar-foreground))]">
                <Activity className="h-4 w-4 text-[hsl(var(--sidebar-primary))]" /> Overview
              </a>
            </nav>
          </div>
          <div className="mt-auto">
            <div className="rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.55)] p-3.5">
              <div className="flex items-center gap-2">
                <span className={`h-2 w-2 rounded-full ${healthQuery.data?.status === 'ok' ? 'bg-[hsl(var(--sidebar-primary))]' : 'bg-[hsl(var(--accent))]'}`} />
                <p data-testid="status-api-health" className="font-mono-ui text-[10px] uppercase tracking-[0.12em] text-[hsl(var(--sidebar-foreground)/.74)]">API {healthQuery.data?.status === 'ok' ? 'healthy' : 'checking'}</p>
              </div>
              <p className="mt-2 text-[11px] leading-4 text-[hsl(var(--sidebar-foreground)/.45)]">Your data stays on this workspace.</p>
            </div>
            <p className="mt-5 px-2 font-mono-ui text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--sidebar-foreground)/.3)]">quiet.link / v0.1</p>
          </div>
        </aside>

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-10 border-b border-[hsl(var(--border)/.75)] bg-[hsl(var(--background)/.88)] px-5 py-4 backdrop-blur-md sm:px-8 lg:px-12">
            <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-4">
              <div className="flex items-center gap-3 md:hidden">
                <BrandMark />
                <div><p className="text-sm font-extrabold tracking-[-0.03em]">quiet.link</p><p className="font-mono-ui text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))]">Operations</p></div>
              </div>
              <div className="hidden md:block">
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">Workspace / overview</p>
                <p data-testid="text-header-date" className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">One account. Essential signals only.</p>
              </div>
              <div className="flex items-center gap-3">
                <div data-testid="status-header-connection" className="hidden items-center gap-2 sm:flex">
                  <span className={`h-2 w-2 rounded-full ${ready ? 'bg-[hsl(var(--primary))]' : 'bg-[hsl(var(--accent))]'}`} />
                  <span className="font-mono-ui text-[10px] uppercase tracking-[0.14em] text-[hsl(var(--muted-foreground))]">{ready ? 'Session live' : 'Session idle'}</span>
                </div>
                <button type="button" data-testid="button-refresh-dashboard" onClick={() => { statusQuery.refetch(); eventsQuery.refetch(); }} className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] transition-[transform,background-color] hover:rotate-[-20deg] hover:bg-[hsl(var(--muted))]" title="Refresh now"><RefreshCcw className="h-4 w-4" /></button>
                <button type="button" data-testid="button-mobile-menu" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] md:hidden"><Activity className="h-4 w-4" /></button>
              </div>
            </div>
            {mobileMenuOpen && <div data-testid="panel-mobile-menu" className="mt-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 text-xs font-bold shadow-[var(--shadow-sm)]"><a href="/" data-testid="link-mobile-overview" className="flex items-center gap-2 rounded-lg bg-[hsl(var(--secondary))] px-3 py-2 text-[hsl(var(--primary))]"><Activity className="h-4 w-4" /> Overview</a></div>}
          </header>

          <div className="mx-auto max-w-[1320px] space-y-6 px-5 py-8 sm:px-8 lg:px-12 lg:py-10">
            <div className="animate-rise flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <p className="font-mono-ui text-[10px] font-medium uppercase tracking-[0.2em] text-[hsl(var(--primary))]">Live operations</p>
                <h1 data-testid="heading-overview" className="mt-2 text-[clamp(2rem,4vw,3.25rem)] font-extrabold leading-[1.02] tracking-[-0.065em] text-[hsl(var(--foreground))]">A calm view of<br className="sm:hidden" /> your automation.</h1>
                <p className="mt-3 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">Link once, keep the signal visible, and let the noisy work stay out of your way.</p>
              </div>
              <div className="signal-grid hidden h-20 w-44 rounded-xl border border-[hsl(var(--border))] p-3 sm:block">
                <p className="font-mono-ui text-[9px] uppercase tracking-[0.15em] text-[hsl(var(--muted-foreground))]">Last connected</p>
                <p data-testid="text-last-connected" className="mt-3 text-right font-mono-ui text-sm font-medium text-[hsl(var(--foreground))]">{formatTime(status?.lastConnectedAt)}</p>
              </div>
            </div>

            <div className="animate-rise" style={{ animationDelay: '70ms' }}>
              <ConnectionCard
                status={safeStatus}
                isWorking={working}
                onStart={handleStart}
                onLogout={handleLogout}
                onUseQr={handleUseQr}
                onPair={handlePair}
                pairPhone={pairPhone}
                setPairPhone={setPairPhone}
                pairError={pairError}
                pairPending={pairWhatsapp.isPending}
              />
            </div>

            <section className="animate-rise grid gap-3 sm:grid-cols-3" style={{ animationDelay: '130ms' }}>
              {[
                { label: 'Messages read', value: safeStatus.metrics.messagesRead.toLocaleString(), icon: Eye, id: 'messages-read', accent: 'text-[hsl(var(--primary))]' },
                { label: 'Statuses reacted', value: safeStatus.metrics.statusesReacted.toLocaleString(), icon: Zap, id: 'statuses-reacted', accent: 'text-[hsl(var(--accent-foreground))]' },
                { label: 'Session uptime', value: formatDuration(safeStatus.metrics.uptimeSeconds), icon: Clock3, id: 'session-uptime', accent: 'text-[hsl(var(--chart-3))]' },
              ].map((metric) => (
                <div key={metric.id} data-testid={`card-metric-${metric.id}`} className="group rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-2xs)] transition-[transform,box-shadow] hover:-translate-y-0.5 hover:shadow-[var(--shadow-sm)]">
                  <div className="flex items-center justify-between"><span className={`flex h-8 w-8 items-center justify-center rounded-lg bg-[hsl(var(--muted))] ${metric.accent}`}><metric.icon className="h-4 w-4" /></span><ArrowUpRight className="h-4 w-4 text-[hsl(var(--muted-foreground)/.45)] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></div>
                  <p data-testid={`text-metric-${metric.id}`} className="mt-5 font-mono-ui text-[26px] font-medium tracking-[-0.05em] text-[hsl(var(--foreground))]">{metric.value}</p>
                  <p className="mt-1 text-xs font-semibold text-[hsl(var(--muted-foreground))]">{metric.label}</p>
                </div>
              ))}
            </section>

            <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1.25fr)_minmax(360px,.75fr)]">
              <section data-testid="section-activity" className="animate-rise rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-2xs)] sm:p-6" style={{ animationDelay: '180ms' }}>
                <SectionHeading eyebrow="Quiet feed" title="Recent activity" detail="The last signals from your personal session." action={<span className="rounded-full bg-[hsl(var(--muted))] px-2.5 py-1 font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">{events.length} events</span>} />
                {eventsQuery.isLoading ? (
                  <div data-testid="state-events-loading" className="space-y-4"><SkeletonBlock className="h-12 w-full" /><SkeletonBlock className="h-12 w-full" /><SkeletonBlock className="h-12 w-full" /></div>
                ) : events.length ? (
                  <div className="divide-y divide-[hsl(var(--border))]">
                    {events.slice(0, 8).map((event, index) => {
                      const tone = eventTone(event.type);
                      return (
                        <div data-testid={`row-event-${event.id}`} key={event.id} className="group flex gap-3 py-3.5 first:pt-0 last:pb-0">
                          <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${tone === 'warning' ? 'bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]' : tone === 'success' ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]' : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'}`}><EventIcon type={event.type} /></div>
                          <div className="min-w-0 flex-1"><div className="flex items-baseline justify-between gap-3"><p data-testid={`text-event-message-${event.id}`} className="truncate text-xs font-bold text-[hsl(var(--foreground))]">{event.message}</p><time data-testid={`text-event-time-${event.id}`} className="shrink-0 font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">{index === 0 ? 'Now' : formatDateTime(event.createdAt)}</time></div>{event.detail && <p className="mt-1 truncate text-[11px] text-[hsl(var(--muted-foreground))]">{event.detail}</p>}</div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div data-testid="state-events-empty" className="signal-grid flex min-h-44 flex-col items-center justify-center rounded-xl border border-dashed border-[hsl(var(--border))] px-6 text-center"><Activity className="h-7 w-7 text-[hsl(var(--muted-foreground)/.5)]" /><p className="mt-3 text-sm font-bold">Nothing to report yet</p><p className="mt-1 max-w-xs text-xs leading-5 text-[hsl(var(--muted-foreground))]">Link your account and this feed will quietly record important automation signals.</p></div>
                )}
              </section>

              <section data-testid="section-account" className="animate-rise rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--primary))] p-5 text-[hsl(var(--primary-foreground))] shadow-[var(--shadow-sm)] sm:p-6" style={{ animationDelay: '220ms' }}>
                <SectionHeading eyebrow="Session context" title="Account details" detail="Kept intentionally compact." />
                <div className="space-y-1">
                  <div className="flex items-center justify-between border-b border-[hsl(var(--primary-foreground)/.14)] py-3"><span className="flex items-center gap-2 text-xs text-[hsl(var(--primary-foreground)/.6)]"><UserRound className="h-3.5 w-3.5" /> Account</span><span data-testid="text-account-name" className="max-w-[58%] truncate text-right text-xs font-bold">{safeStatus.account ?? 'Not linked'}</span></div>
                  <div className="flex items-center justify-between border-b border-[hsl(var(--primary-foreground)/.14)] py-3"><span className="flex items-center gap-2 text-xs text-[hsl(var(--primary-foreground)/.6)]"><Smartphone className="h-3.5 w-3.5" /> Device</span><span data-testid="text-device-name" className="max-w-[58%] truncate text-right text-xs font-bold">{status?.device ?? 'Waiting for device'}</span></div>
                  <div className="flex items-center justify-between py-3"><span className="flex items-center gap-2 text-xs text-[hsl(var(--primary-foreground)/.6)]"><ShieldCheck className="h-3.5 w-3.5" /> Privacy</span><span data-testid="status-privacy" className="flex items-center gap-1.5 text-xs font-bold"><CheckCircle2 className="h-3.5 w-3.5 text-[hsl(var(--sidebar-primary))]" /> Local session</span></div>
                </div>
                <div className="mt-5 rounded-xl bg-[hsl(var(--primary-foreground)/.08)] p-3.5"><p className="text-xs font-bold">Automation is {ready ? 'standing by' : 'paused'}</p><p className="mt-1 text-[11px] leading-5 text-[hsl(var(--primary-foreground)/.55)]">{ready ? 'Rules are running with the timing and presence controls below.' : 'Link a session to make your rules available.'}</p></div>
              </section>
            </div>

            <ChatsSection
              chats={chats}
              chatsLoading={chatsQuery.isLoading}
              messages={chatMessagesQuery.data ?? []}
              messagesLoading={chatMessagesQuery.isLoading}
              selectedChatId={selectedChatId}
              onSelectChat={setSelectedChatId}
              draft={chatDraft}
              setDraft={setChatDraft}
              onSend={handleSendChatMessage}
              sending={sendChatMessage.isPending}
            />

            <section data-testid="section-automation" className="animate-rise rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-2xs)] sm:p-6" style={{ animationDelay: '260ms' }}>
              <SectionHeading eyebrow="Control room" title="Automation settings" detail="Changes apply to the connected account as soon as they are saved." action={settingsSaved ? <span data-testid="status-settings-saved" className="flex items-center gap-1.5 text-xs font-bold text-[hsl(var(--primary))]"><Check className="h-4 w-4" /> Saved</span> : <span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">AUTO-SAVE ON TOGGLES</span>} />
              <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
                <div>
                  <p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))]">Passive actions</p>
                  <div className="mt-2">
                    <Toggle checked={settings.autoRead} onChange={(value) => updateSetting('autoRead', value)} label="Mark incoming messages read" description="Keep conversations from piling up as unread." testId="toggle-auto-read" />
                    <Toggle checked={settings.autoReactMessages} onChange={(value) => updateSetting('autoReactMessages', value)} label="React to all messages" description="React to every incoming chat message after a random delay." testId="toggle-auto-react-messages" />
                    <Toggle checked={settings.autoReactStatus} onChange={(value) => updateSetting('autoReactStatus', value)} label="React to statuses" description="Send a small reaction to status updates." testId="toggle-auto-react-status" />
                    <Toggle checked={settings.keepPresenceOnline} onChange={(value) => updateSetting('keepPresenceOnline', value)} label="Keep presence online" description="Show an active presence while the session is connected." testId="toggle-keep-presence" />
                    <div className="border-b border-[hsl(var(--border))] py-4">
                      <div className="flex items-center justify-between"><div><p className="text-[13px] font-semibold">Random response delay</p><p className="mt-0.5 text-[11px] text-[hsl(var(--muted-foreground))]">Make automated actions feel less mechanical.</p></div><span data-testid="text-delay-range" className="font-mono-ui text-[11px] text-[hsl(var(--primary))]">{settings.randomDelayMin}–{settings.randomDelayMax}s</span></div>
                      <div className="mt-3 grid grid-cols-2 gap-3"><label className="text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">Minimum<input data-testid="input-delay-min" type="number" min="1" max="10" value={settings.randomDelayMin} onChange={(event) => updateSetting('randomDelayMin', Number(event.target.value))} className="mt-1 h-9 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-2 font-mono-ui text-xs outline-none focus:border-[hsl(var(--primary))]" /></label><label className="text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">Maximum<input data-testid="input-delay-max" type="number" min="1" max="10" value={settings.randomDelayMax} onChange={(event) => updateSetting('randomDelayMax', Number(event.target.value))} className="mt-1 h-9 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-2 font-mono-ui text-xs outline-none focus:border-[hsl(var(--primary))]" /></label></div>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))]">Conversation rules</p>
                  <div className="mt-2">
                    <Toggle checked={settings.commandsEnabled} onChange={(value) => updateSetting('commandsEnabled', value)} label="Built-in commands" description="Reply to !ping, !time, and !help." testId="toggle-commands" />
                    <Toggle checked={settings.autoReply} onChange={(value) => updateSetting('autoReply', value)} label="Away reply" description="Send a one-time message to direct chats." testId="toggle-auto-reply" />
                    <label className="block border-b border-[hsl(var(--border))] py-4 text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">Away reply message<textarea data-testid="textarea-auto-reply-message" value={settings.autoReplyMessage} onChange={(event) => setSettings({ ...settings, autoReplyMessage: event.target.value })} rows={2} className="mt-1.5 w-full resize-none rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2 text-xs font-normal leading-5 text-[hsl(var(--foreground))] outline-none focus:border-[hsl(var(--primary))]" /></label>
                    <Toggle checked={settings.welcomeNewMembers} onChange={(value) => updateSetting('welcomeNewMembers', value)} label="Welcome new members" description="Greet people when they join a group." testId="toggle-welcome-members" />
                    <label className="block border-b border-[hsl(var(--border))] py-4 text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">Welcome message<textarea data-testid="textarea-welcome-message" value={settings.welcomeMessage} onChange={(event) => setSettings({ ...settings, welcomeMessage: event.target.value })} rows={2} className="mt-1.5 w-full resize-none rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2 text-xs font-normal leading-5 text-[hsl(var(--foreground))] outline-none focus:border-[hsl(var(--primary))]" /></label>
                  </div>
                  <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                    <label className="flex-1 text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">Ignored numbers<span className="mt-1 block text-[10px] font-normal">One number per line, digits only.</span><textarea data-testid="textarea-ignored-numbers" value={settings.ignoredNumbers.join('\n')} onChange={(event) => setSettings({ ...settings, ignoredNumbers: event.target.value.split('\n').map((number) => number.replace(/[^\d]/g, '')).filter(Boolean) })} rows={2} placeholder="2348012345678" className="mt-1.5 w-full resize-none rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2 font-mono-ui text-xs font-normal leading-5 text-[hsl(var(--foreground))] outline-none focus:border-[hsl(var(--primary))]" /></label>
                    <button type="button" data-testid="button-save-message-settings" onClick={saveMessage} disabled={updateWhatsappSettings.isPending} className="inline-flex h-10 shrink-0 items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 text-xs font-bold text-[hsl(var(--primary-foreground))] transition-[transform,opacity] hover:-translate-y-0.5 hover:opacity-90 disabled:opacity-50">{updateWhatsappSettings.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Save copy</button>
                  </div>
                </div>
              </div>
            </section>

            <footer className="flex flex-col justify-between gap-2 border-t border-[hsl(var(--border))] pt-5 text-[10px] text-[hsl(var(--muted-foreground))] sm:flex-row sm:items-center">
              <p className="font-mono-ui uppercase tracking-[0.14em]">quiet.link / private by default</p>
              <p className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Session signals refresh automatically</p>
            </footer>
          </div>
        </main>
      </div>
    </div>
  );
}

export default Home;