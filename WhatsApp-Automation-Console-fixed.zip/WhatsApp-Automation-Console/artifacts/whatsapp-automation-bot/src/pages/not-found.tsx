import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="noise-layer flex min-h-[100dvh] w-full items-center justify-center bg-[hsl(var(--background))] p-6">
      <Card className="w-full max-w-md border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[var(--shadow-lg)]">
        <CardContent className="p-7">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]">
              <AlertCircle className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-bold tracking-[-0.03em] text-[hsl(var(--foreground))]">
              This signal is missing
            </h1>
          </div>

          <p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">
            There is no quiet.link workspace at this address. Return to the live operations overview.
          </p>
          <a href="/" data-testid="link-return-overview" className="mt-6 inline-flex h-10 items-center rounded-xl bg-[hsl(var(--primary))] px-4 text-xs font-bold text-[hsl(var(--primary-foreground))] transition-opacity hover:opacity-90">
            Return to overview
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
