---
name: Package-scoped dependency installs
description: Workspace-specific dependency installation behavior for this monorepo.
---

When a dependency belongs to one workspace package, install it with a package-scoped pnpm command rather than the generic language-package helper.

**Why:** The generic helper runs `pnpm add` from the workspace root and is rejected by pnpm's root-package guard in this monorepo.

**How to apply:** Use `pnpm --filter @workspace/<package> add ...` for runtime dependencies and `pnpm --filter @workspace/<package> add -D ...` for development-only dependencies.